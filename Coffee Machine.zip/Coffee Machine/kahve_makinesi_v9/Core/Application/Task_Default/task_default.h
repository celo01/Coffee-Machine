/*
 * task_default.h
 *
 *  Created on: Feb 1, 2023
 *      Author: alpdade
 */

#ifndef INC_TASK_DEFAULT_H_
#define INC_TASK_DEFAULT_H_


void task_default_init();
void task_default_process();


#endif /* INC_TASK_DEFAULT_H_ */
