/*
 * relay.c
 *
 *  Created on: Feb 1, 2023
 *      Author: alpdade
 */



//----------- INCLUDES ---------- //


#include "relay.h"




//----------- VARIABLES ---------- //


extern RelayStatus relay_status;

//----------- FUNCTIONS ---------- //



