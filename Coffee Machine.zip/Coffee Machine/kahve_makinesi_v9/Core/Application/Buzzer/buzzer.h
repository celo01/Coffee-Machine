/*
 * buzzer.h
 *
 *  Created on: Feb 1, 2023
 *      Author: alpdade
 */

#ifndef INC_BUZZER_H_
#define INC_BUZZER_H_


void buzzer_init();
void buzzer_play_melody1();
void buzzer_play_melody2();
void buzzer_play_melody3();
void buzzer_play_melody4();
void buzzer_play_melody5();
void buzzer_play_melody6();
void buzzer_play_melody7();
void buzzer_play_melody8();
void buzzer_play_melody9();
void buzzer_play_melodyC();

#endif /* INC_BUZZER_H_ */
