/*
 * degiskenler.c
 *
 *  Created on: Jan 7, 2025
 *      Author: USER
 */

#include "main.h"
#include "degiskenler.h"
uint32_t zaman_count = 0;
uint32_t zaman_count100 = 0;
uint8_t zaman_say = 0;
uint8_t zaman_durdur = 0;
uint16_t disp_flasor = 0;
uint16_t sayim_timer = 0;


uint8_t mod1_digit2 = 0;
uint8_t mod1_digit3 = 0;
uint8_t mod2_digit1 = 0;
uint8_t mod2_digit2 = 0;
uint8_t mod2_digit3 = 0;
